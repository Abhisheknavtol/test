var wmsurl190='wmsurl190/';

var format = new ol.format.WKT();
window.onload=maininit;
var map;
var keymap;
var layerurls;
var intersectlayername;
//var districtbox;
function maininit()
{

$(".ol-scale-line-inner").hide();


  var date = new Date(); 
var dd = date.getDate(); 
var mm = date.getMonth()+1; 
var yyyy = date.getFullYear(); 
 const today=dd+"/"+mm+"/"+yyyy;
 document.getElementById('date').innerHTML=today;

/*var url_string = window.location;
    let url = new URL(url_string);
    let data = url.searchParams.get("id");
    let d=JSON.parse(Base64.decode(data));
  
    layers=d.layername;
    layerurls=d.priturls;
    
    
    let resolution=d.resolution;
    let center=d.center;
    wkt=d.wkt;   */
   
  document.getElementById('username').innerHTML = username;
  document.getElementById('mtitle').innerHTML = mapTitle;
  document.getElementById('ProjectTitle').innerHTML = ProjectTitle;
  document.getElementById('ref').innerHTML = refrence;
  document.getElementById('rev').innerHTML = revisionno;
//    let pagesize=d.pagesize;
//    let mapdpi=d.mapdpi;
  
    let printlatlon = ol.proj.transform(center, 'EPSG:3857', 'EPSG:4326');
 
      let data_dist = getdistrictbylatlondata(printlatlon);
   
  if(data_dist[0]!=undefined)
  {
    var dist_cql = "first_dist IN ('"+data_dist[0].dist_id+"')"; 
    }
  
	var centrepointmap;
	var centrepointkeymap;

   if(pagesize=="A3_Landscape")
   {
     centrepointmap=[71.1924,22.2587];
     centrepointkeymap=[71.1626,22.8703];
   }
   if(pagesize=="A3_Portrait")
   {
     centrepointmap=[69.6444,23.4870];
     centrepointkeymap=[72.1039,22.8817];
   }
   if(pagesize=="A4_Landscape")
   {
     centrepointmap=[71.1924,22.2587];
     centrepointkeymap=[73.1626,22.8703];
   }
   if(pagesize=="A4_Portrait")
   {
     centrepointmap=[69.6444,23.4870];
     centrepointkeymap=[72.1039,22.8817];
   }
     
     
   map = new ol.Map({
	
        target: 'target-map',
       
        view: new ol.View({
        	center : ol.proj.transform(centrepointmap, 'EPSG:4326','EPSG:3857'),

       zoom:7.0,
      
			minZoom:4,
			maxZoom: 50
        }),
           layers:[

        		new ol.layer.Tile({
										visible : false,
									//	source: new ol.source.TileImage({url: 'http://mt1.google.com/vt/lyrs=r&x={x}&y={y}&z={z}'}),
											 source: new ol.source.TileImage({ url: 'http://mt1.google.com/vt/lyrs=y&x={x}&y={y}&z={z}' }),
									
										
										name : 'High Resolution Image'
									}),
									 

    	],
      controls:   ol.control.defaults({
        zoom: false,
        attribution: true,
        rotate: false
      }).extend([
      new ol.control.ScaleLine({
        className: 'ol-scale-line',
        target: document.getElementById('scale-line')
    })
      
      ]),

    

      });

 var dist= new ol.layer.Tile({
				source : new ol.source.TileWMS({
					url :wmsurl190,
					crossOrigin: 'anonymous',
					params : {
						'LAYERS' : 'gujarat_district',
						
						version : '1.1.1',format_options:'dpi:110'
						
					}
				}),
				showLegend: true,
				
				name : 'District Boundary',
				visible:true
					
			});
 var dist_highlight= new ol.layer.Tile({
				source : new ol.source.TileWMS({
					url :wmsurl190,
					crossOrigin: 'anonymous',
					params : {
						'LAYERS' : 'gujarat_district',
						
						version : '1.1.1',format_options:'dpi:110',
						CQL_FILTER : dist_cql,
						STYLES:'highlight_polygon'
						
						//version : '1.1.1',CQL_FILTER : 'dtcode11 IN (001,003,004)' ,format_options:'dpi:110' 
					}
				}),
				showLegend: true,
				//maxResolution : 2048,
				name : 'District Boundary',
				visible:true
					
			});
      if (kmlKmzWkt) {
        
        const kmlKmzFeature = new ol.format.WKT().readFeature(kmlKmzWkt, {
          dataProjection: "EPSG:4326",
          featureProjection: "EPSG:3857",
        });
        const wktSource = new ol.source.Vector({ features: [kmlKmzFeature] })
        const wktLayer = new ol.layer.Vector({ source: wktSource });
        map.addLayer(wktLayer);
        // kmlchange
      }
      // kml change
      // buffer change
  if (bufferwkt) {
    const bufferLayer = new ol.layer.Tile({
      source: new ol.source.TileWMS({
        url: wmsurl190,        
        crossOrigin: 'anonymous',
        params: {
          'LAYERS': bufferwkt,
          version: '1.1.1',
          transparent: 'true',
          CQL_FILTER: cqlbuffer
        }
      }),
      showLegend: true,
      visible: true
    });
    var removeSelectedLayer = [];
    map.addLayer(bufferLayer);
    $.getJSON("getwktclip/" + cqlbuffer + "/" + bufferwkt, function (response) {
      var grey = new ol.style.Style({
        stroke: new ol.style.Stroke({
          color: "grey",
          width: 2
        }),
      });
      
      for (var i = 0; i < response.length; i++) {
        var ls_wkt = response[i].wkt;
        var ls_geojson = Terraformer.WKT.parse(ls_wkt);
        var ls = turf.feature(ls_geojson);
        var buffered = turf.buffer(ls, bufferrange, { units: 'meters' });
        var wkt = Terraformer.WKT.convert(buffered['geometry']);
        var format = new ol.format.WKT();
        var feature = format.readFeature(wkt, {
          dataProjection: 'EPSG:4326',
          featureProjection: 'EPSG:3857'
        });
        vector = new ol.layer.Vector({
          source: new ol.source.Vector({
            features: [feature]
          }),
          style: [grey],
          name: 'redflaglayer'
        });
        if (i == 0) {
          map.addLayer(vector);
          removeSelectedLayer.push(vector);
        } else {
          var layerfind = findlayeByName(map.getLayerGroup(), 'name', 'redflaglayer');
          layerfind.getSource().addFeature(feature);
        }

      }
    })
  }

     
   map.on('postrender', function(e)
    {
          resolution = map.getView().getResolution();
    	const dpi = 25.4 / 0.28;
	let scale = resolution * 39.37 * dpi;
	 document.getElementById('scale').innerHTML=scale.toFixed(0);
	 
	
	 $("#scale1").html($(".ol-scale-line-inner").html());
	});
        
      keymap = new ol.Map({
	
        target: 'key-map',       
        view: new ol.View({
        	center : ol.proj.transform(centrepointkeymap, 'EPSG:4326','EPSG:3857'),
            zoom:5.0,     
			minZoom:4,
			maxZoom: 50
        }),
           layers:[dist],
      controls:   ol.control.defaults({
        zoom: false,
        attribution: true,
        rotate: false
      }).extend([]),

    

      });
      
 
              if(resolution<360)
    {
    
    keymap.addLayer(dist_highlight);
    }
    
      
       map.getView().setResolution(resolution);
   map.getView().setCenter(center);

   basiclayers(); 
  measurement(map);
   
   if(wkt!=null)
   {
   
    wktfunctions(); 
    }
    
    let dragAndDropInteraction;

    function setInteraction() {
      if (dragAndDropInteraction) {
        map.removeInteraction(dragAndDropInteraction);
      }
      dragAndDropInteraction = new ol.interaction.DragAndDrop({
        formatConstructors: [
       // ol.format.KMZ,
          ol.format.GPX,
          ol.format.GeoJSON,
          ol.format.IGC,
          // use constructed format to set options
           ol.format.KML,
           
          ol.format.TopoJSON,
        ],
      });
      dragAndDropInteraction.on('addfeatures', function (event) {
        const vectorSource = new ol.source.Vector({
          features: event.features,
        });
        map.addLayer(
          new ol.layer.Vector({
            source: vectorSource,
          })
        );
        map.getView().fit(vectorSource.getExtent());
      });
      map.addInteraction(dragAndDropInteraction);
    }
    setInteraction();
  

 
    }
 
 
    
 




function basiclayers()
{



   for(var i=0;i<layers.length;i++)
       {
       
       
       
        let maplayers = new ol.layer.Tile({
     source : new ol.source.TileWMS({
       url :layerurls[0],
       crossOrigin: 'anonymous',
       params : {
         'LAYERS' : layers[i],
         format_options:'dpi:180',
         version : '1.1.1',
         STYLES:'',
        
       }
     }),
     showLegend: false,
  
     name : 'geomintersectlayer'+[i],
     visible:true
   });
 
  map.addLayer(maplayers);
       
       
     
       legendImg =legendurl(layerurls[i],layers[i]);
       
      
      
       divimg = '<div id="img' +i+ '"></div>';
	
	$("#legend").append(divimg);
	
	var myContainer = document.getElementById('img'+i);
	
	var myimg = document.createElement("img");
		myimg.src = legendImg;
	
		myContainer.appendChild(myimg);
		
		
     
} 
     
  
}
function intersectlayersfunction()
    {      
    
      for(var j=0;j<intersectlayername.length;j++)
     {
     var cqldata=intersectservices(wkt,intersectlayername[j]);
     for(var k=0;k<cqldata.length;k++)
     {    
       var cqlfilter;
  
  var gid="gid="+cqldata[k].gid;
 
  
  var n="cat='"+cqldata[k].cat+"'";
  
  if(intersectlayername[j]=='gujarat_road')
  {
 
  cqlfilter=gid+' and '+n;
  }
  else
  {
  cqlfilter="gid="+cqldata[k].gid;
  }

let geomintersectlayerprint = new ol.layer.Tile({
     source : new ol.source.TileWMS({
       url :wmsurl190,
       crossOrigin: 'anonymous',
       params : {
         'LAYERS' : intersectlayername[j],
         format_options:'dpi:180',
         version : '1.1.1',
         STYLES:'',
         CQL_FILTER : cqlfilter
       }
     }),
     showLegend: false,
  
     name : 'geomintersectlayer',
     visible:true
   });
  //map.addLayer(geomintersectlayerprint);
  keymap.addLayer(geomintersectlayerprint);   
  }    
 }
}
function wktfunctions()
{
 var feature = format.readFeature(wkt);
 feature.getGeometry().transform('EPSG:4326', 'EPSG:3857');
 var wktlayers = new ol.layer.Vector({
   source: new ol.source.Vector({
     features: [feature],
   }),
 });

 map.addLayer(wktlayers);
// keymap.addLayer(wktlayers);

 let NOC="noc";
 legendImg =legendurl(NOC);
  
 
 
 divimg = '<div id="img' +3+ '"></div>';

$("#legend").append(divimg);

var myContainer = document.getElementById('img'+3);

var myimg = document.createElement("img");
myimg.src = legendImg;


myContainer.appendChild(myimg);


}
  
function zoomIn()
    {
        
    map.getView().animate({
            zoom: map.getView().getZoom() + 1,
            duration: 500
          });
    
    
    
      
    }
    
    function zoomOut()
    {
    
      map.getView().animate({
            zoom: map.getView().getZoom() - 1,
            duration: 500
          });
    }
    
    
   
$("#sholayers").click(function(){

  var checkBox = document.getElementById("myCheck");
  
  map.getLayers().forEach(function (layer) {
  
    if(layer.get('name')=="High Resolution Image")
    {
      layer.setVisible(checkBox.checked );
    }
  });


});

  function legendurl(url,layername)
  {
  
  
	
	
      return  url+'?REQUEST=GetLegendGraphic&sld_version=1.0.0&layer=' + layername + '&format= image/png &legend_options=fontSize:13;fontName:san-sarif;bgColor:0xffffff;forceLabels:on' + '&WIDTH=12&HEIGHT=12&Scale=1';
     
  
  
  

 
   }

